<?php
$ip=$_SERVER['REMOTE_ADDR'];
$ipm=md5(ip);
echo "IP do usuário: ".$ip;
echo "<br>";
echo "IP do usuário mascarado: ".$ipm;
?>