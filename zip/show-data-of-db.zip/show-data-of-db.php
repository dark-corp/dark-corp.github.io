<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar dados</title>
</head>
<body>
<?php
$connection = new mysqli("localhost", "usuario", "senha", "banco-de-dados");/* conexao com o host e BD */
$sql = $connection->query('SELECT * FROM tabela'); /* troque 'tabela' pelo nome da sua tabela */
while($exibe = mysqli_fetch_assoc($sql)){
    $d1 = $exibe['id'];/* nomes */
    $d2 = $exibe['nome']; /* das */
    $d3 = $exibe['email']; /* suas */
    $d4 = $exibe['senha']; /* colunas*/
    /* exibir os dados */
    echo "<a>".$d1."</a><br>";
    echo "<a>".$d2.": </a><br>";
    echo "<a>".$d3." </a><br>" ;
    echo "<a>".$d4e."</a><br>";
    echo "<br><br>";
}
?>
</body>
</html>